
# Team 39 STI Pekanbaru - Streamlit Web App

Aplikasi monitoring jarak dengan sensor ultrasonic dan kontrol servo berbasis web.

🚀 Dibuat oleh Team 39 STI Pekanbaru  
🖥️ Dibuat menggunakan Streamlit + ESP8266

Fitur:
- Menampilkan data jarak dari sensor ultrasonic
- Kontrol servo dari web app

Akses online: (link akan muncul setelah deploy)
