
import streamlit as st
import random

st.set_page_config(page_title="Team 39 STI Pekanbaru", layout="centered")

st.title("📡 Monitoring Sensor Ultrasonic & Kontrol Servo")
st.subheader("by Team 39 STI Pekanbaru")

# Simulasi pembacaan sensor ultrasonic
def read_distance():
    return round(random.uniform(5, 100), 2)

distance = read_distance()

st.metric("Jarak Terdeteksi", f"{distance} cm")

# Kontrol servo
angle = st.slider("Atur Sudut Servo", 0, 180, 90)

st.write(f"Servo diarahkan ke {angle}°")

if st.button("Kirim ke ESP"):
    st.success(f"Sudut servo ({angle}°) berhasil dikirim!")
